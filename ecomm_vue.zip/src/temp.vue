<template>
<div id="wraper">
  <nav class="navbar is-dark">
    <div class="navbar-brand">
      <router-link class="navbar-item" to="/">
        <strong>Home</strong>
      </router-link>
    </div>
    <div class="navbar-menu">
      <div class="navbar-start"></div>
      <div class="navbar-end">
          <router-link class="navbar-item" to="/">Summer</router-link>
          <router-link class="navbar-item" to="/">Winter</router-link>
          <div class="navbar-item">
            <div class="buttons">
              <router-link class="button is-light" to="/">Login</router-link>
              <router-link class="button is-success" to="/">Cart</router-link>
            </div>
          </div>
      </div>
    </div>
  </nav>

  <section class="section">
    <router-view/>
  </section>
  <footer class="footer">
    <p class="has-text-centered">Copyright (c) 2021</p>
  </footer>
</div>
</template>

<style lang="scss">
@import '../node_modules/bulma';
</style>
