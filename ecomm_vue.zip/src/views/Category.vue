<template>
  <div class="page-category">
    <div class="columns is-multiline">
      <div class="column is-12">
        <h2 class="is-size-2 has-text-centered">
          {{ category.name }}
        </h2>
      </div>

      <ProductBox
        v-for="p in category.products"
        :key="p.id"
        :product="p"
      />
    </div>
  </div> 
</template>

<script>
import axios from 'axios'
import ProductBox from '@/components/ProductBox.vue'

export default {
  name: 'CategoryView',
  components: { ProductBox },
  data() {
    return {
      category: {
        name: '',
        products: []
      }
    }
  },
  mounted() {
    this.getCategory()
  },
  watch: {
    $route(to,) {
      if (to.name === 'category') {
        this.getCategory()
      }
    }
  },
  methods: {
    getCategory() {
      const categorySlug = this.$route.params.category_slug
      axios
        .get(`/api/v1/products/${categorySlug}`)
        .then(response => {
          this.category = response.data
        })
        .catch(error => {
          console.log(error)
        })

    }
  }
  
}
</script>