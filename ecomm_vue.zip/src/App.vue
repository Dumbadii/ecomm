<template>
<div id="wraper">
  <nav class="navbar is-dark">
    <div class="navbar-brand">
      <router-link class="navbar-item" to="/">
        <strong>Home</strong>
      </router-link>
      <a class="navbar-burger" aria-label="menu" aria-expanded="false" data-target="navbar-menu" @click="showMobileMenu = !showMobileMenu">
        <span aria-hidden="true"></span>
        <span aria-hidden="true"></span>
        <span aria-hidden="true"></span>
      </a>

    </div>
    <div class="navbar-menu" id="navbar-menu" :class="{'is-active': showMobileMenu}">
      <div class="navbar-start">
        <div class="navbar-item">
          <form method="get" action="/search/">
            <div class="field has-addons">
              <div class="control">
                <input type="text" class="input" placeholder="What are you looking for?" name="query">
              </div>
              <div class="control">
                <button class="button is-succes">
                  <span class="icon">
                    <i class="fas fa-search"></i>
                  </span>
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
      <div class="navbar-end">
          <router-link class="navbar-item" to="/products/Summer/">Summer</router-link>
          <router-link class="navbar-item" to="/products/Winter">Winter</router-link>
          <div class="navbar-item">
            <div class="buttons">
              <router-link v-if="!$store.state.isAuthenticated" class="button is-light" to="/login">
                Login
              </router-link>
              <router-link v-if="$store.state.isAuthenticated" class="button is-light" to="/my-account">
                Account
              </router-link>
              <router-link class="button is-success" to="/cart">
                <span class="icon"><i class="fas fa-shopping-cart"></i></span>
                <span>Cart ({{ cartTotalLength }})</span>
              </router-link>
            </div>
          </div>
      </div>
    </div>
  </nav>

  <!-- <CartView v-if="showCart" class="width:200px;aligned: right" /> -->
  <section class="section">
    <router-view/>
  </section>
  <footer class="footer">
    <p class="has-text-centered">Copyright (c) 2021</p>
  </footer>
</div>
</template>

<style lang="scss">
@import '../node_modules/bulma';
</style>

<script>
export default {
  data() {
    return {
      showMobileMenu: false,
      showCart: false,
      cart: {
        items: []
      }
    }
  },
  beforeCreated() {
    this.$store.commit('initializeStore')
  },
  computed: {
    cartTotalLength() {
      return this.cart.items.reduce((acc, cur) => acc + cur.quantity, 0)
    }
  },
  mounted() {
    this.cart = this.$store.state.cart
    document.title = 'Home | Djackets'
  },
  watch: {
    $route(to,) {
      if (to.name === 'success') {
        this.cart = this.$store.state.cart
      }
    }
  },
}
</script>